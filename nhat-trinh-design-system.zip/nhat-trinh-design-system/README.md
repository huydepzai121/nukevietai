# Nhật Trình — Design System

Hệ thống thiết kế dùng chung cho **mọi loại website**: giới thiệu doanh nghiệp,
landing page, bán hàng, blog, tin tức, hồ sơ cá nhân, trang tài liệu.
Phong cách **báo in cổ điển**: giấy ngà, mực đen, đỏ nhấn, hai họ chữ serif,
không bo góc, không đổ bóng. Viết bằng HTML/CSS thuần, không cần build.

## Cách dùng

Nạp đúng thứ tự trong `<head>`:

```html
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,500;0,700;0,900;1,500&family=Noto+Serif:wght@400;600;700&display=swap">
<link rel="stylesheet" href="tokens.css">
<link rel="stylesheet" href="base.css">
<link rel="stylesheet" href="components.css">
<!-- CSS riêng của trang/dự án nạp sau cùng -->
```

## Nội dung gói

| File | Nội dung |
|------|----------|
| `tokens.css` | **Nguồn sự thật**: màu, chữ, khoảng cách, bố cục, ô giữ chỗ ảnh |
| `base.css` | Reset, chữ nền, `.container`, `.section`, lưới, điểm ngắt |
| `components.css` | Thành phần dùng chung (danh sách bên dưới) |
| `index.html` | Trang tổng quan, dẫn tới mọi preview và ví dụ |
| `previews/*.html` | Từng nhóm: màu, chữ, khoảng cách, nút, biểu mẫu, thẻ, điều hướng, nhãn/bảng, ảnh, mẫu section |
| `examples/business.html` | Ví dụ website doanh nghiệp/dịch vụ một trang |
| `examples/news/` | Ví dụ website tin tức nhiều trang (bản gốc của phong cách này) |

## Token

`tokens.css` có hai lớp:

- **Nguyên liệu** `--nt-*`: giá trị gốc. Không dùng trực tiếp trong thành phần mới.
- **Ngữ nghĩa** `--color-*`, `--font-*`, `--text-*`, `--space-*`…: đặt tên theo vai trò.
  Mọi thành phần chỉ dùng lớp này. Muốn đổi thương hiệu, chỉ sửa lớp này.

### Màu

| Token | Giá trị | Vai trò |
|-------|---------|---------|
| `--color-bg` | `#f7f3ea` | Nền trang (không dùng trắng thuần) |
| `--color-surface` | `#fffdf7` | Thẻ, ô nhập, hộp nổi |
| `--color-surface-alt` | `#f2ece0` | Section xen kẽ, nền phụ |
| `--color-inverse` | `#14110d` | Nền tối: thanh trên cùng, chân trang, khối CTA |
| `--color-text` | `#14110d` | Tiêu đề |
| `--color-text-body` | `#3d372e` | Đoạn văn |
| `--color-text-muted` | `#7a7266` | Phụ chú, ngày giờ, nhãn |
| `--color-text-subtle` | `#9a9184` | Placeholder, mục bị tắt |
| `--color-accent` | `#a8231c` | Liên kết, CTA, nhãn, trạng thái chọn |
| `--color-accent-hover` | `#7c1813` | Hover |
| `--color-highlight` | `#d8b26a` | Điểm nhấn, **chỉ trên nền tối** |
| `--color-border` | `#d8cfbe` | Viền ô nhập, thẻ, dải phân cách |
| `--color-border-strong` | `#14110d` | Kẻ đôi, gạch chân tiêu đề, khung nhấn |
| `--color-border-dotted` | `#cfc5b2` | Kẻ chấm giữa các dòng danh sách |
| `--color-success` / `-bg` | `#3f5a2e` / `#e9ecdc` | Thông báo thành công |
| `--color-warning` / `-bg` | `#8a5a12` / `#f4e7c9` | Cảnh báo |
| `--color-danger` / `-bg` | `#a8231c` / `#f6e6e2` | Lỗi |

### Chữ

- **Tiêu đề** `--font-display`: Playfair Display (500, 700, 900, nghiêng 500)
- **Thân và giao diện** `--font-body`: Noto Serif (400, 600, 700)

| Token | Cỡ | Dùng cho |
|-------|----|----------|
| `--text-display` | 62px | Logo chữ, hero rất lớn (Playfair 900) |
| `--text-h1` | 36px | Tiêu đề trang (hero dùng 48px qua `.hero__title`) |
| `--text-h2` | 28px | Tiêu đề mục |
| `--text-h3` | 20px | Tiêu đề thẻ |
| `--text-lead` | 15.5px / 1.65 | Đoạn dẫn |
| `--text-body` | 15px / 1.55 | Chữ giao diện |
| `--text-article` | 16px / 1.85 | Thân bài dài (không nhỏ hơn) |
| `--text-xs` | 12px | Phụ chú |
| `--text-label` | 10.5px, hoa, dãn .16em | Nhãn (eyebrow) |

Trên điện thoại (≤ 640px) các cỡ lớn tự giảm: display 40, h1 28, h2 23.

### Khoảng cách và bố cục

- Thang: 4 · 8 · 12 · 16 · 20 · 24 · 30 · 40 · 56 · 80 (`--space-1` … `--space-10`).
- Khung `.container` 1080px, `.container--narrow` 720px, gutter 30px.
- Giữa các section lớn: 80px (56px trên điện thoại).
- Lưới: `.grid-2/3/4`, `.layout-sidebar` (nội dung + cột 255px), `.layout-3col` (210 / nội dung / 255).
- Điểm ngắt: ≤ 960px lưới 3–4 cột về 2 cột; ≤ 640px về 1 cột. Vùng chạm ≥ 44px.

### Hình khối

- `--radius: 0` — không bo góc ở bất kỳ đâu.
- `--shadow: none` — phân lớp bằng đường kẻ, không bằng bóng.
- Kẻ đôi `.rule-double` (3px + 1px mực) ngăn các tầng lớn như đầu trang và menu.
- Tiêu đề khối `.section-title`: gạch chân 2px mực.
- Khung nhấn: viền 2px mực (`.card--featured`).
- Danh sách: kẻ chấm 1px.

## Thành phần

| Nhóm | Class |
|------|-------|
| Chữ biên tập | `.eyebrow` (`--plain`), `.display`, `.tagline`, `.lead`, `.meta`, `.prose`, `.quote`, `.numeral`, `.section-title`, `.rule-double` |
| Nút | `.btn`, `.btn-primary`, `.btn-dark`, `.btn-link`, `.btn-sm`, `.btn-lg`, `.btn-block` |
| Biểu mẫu | `.field`, `.label`, `.input`, `.select`, `.textarea`, `.help`, `.check`, `.input-group`, trạng thái `.is-invalid` |
| Thẻ | `.card` + `__media`, `__title`, `__text`; biến thể `--row`, `--boxed`, `--featured` |
| Danh sách | `.list-ruled`, `.list-ranked` (đánh số đỏ), `.spec` (thông số) |
| Nhãn | `.tag`, `.badge` (`--dark`, `--outline`) |
| Thông báo | `.alert` (`--info`, `--success`, `--warning`, `--danger`) |
| Bảng | `.table`, cột số `.num` |
| Điều hướng | `.topbar`, `.site-header`, `.brand`, `.nav` + `.nav__list`, `.breadcrumbs`, `.tabs`, `.pager` |
| Section | `.section` (`--alt`, `--inverse`), `.hero` + `__title`, `__media`, `.cta`, `.site-footer`, `.footer-grid`, `.footer-title`, `.footer-links`, `.footer-bottom` |
| Ảnh | `.ph`, `.ph--2` … `.ph--8`, `.media`, `.figure` |
| Bố cục | `.container`, `.grid`, `.stack`, `.stack-lg`, `.cluster` |

Trạng thái chọn dùng thuộc tính ARIA: `aria-current="page"` cho menu và phân trang,
`aria-selected="true"` cho tab.

## Áp dụng cho từng loại website

| Loại | Gợi ý |
|------|-------|
| Doanh nghiệp / dịch vụ | `.hero` → dịch vụ đánh số `.numeral` → dự án `.card` → bảng giá `.card--featured` → `.quote` → biểu mẫu liên hệ. Xem `examples/business.html` |
| Landing page | Một CTA đỏ chính, section xen kẽ `.section--alt`, kết thúc bằng `.cta` nền mực |
| Bán hàng | `.card` sản phẩm + `.numeral` cho giá, `.spec` cho thông số, `.badge` cho khuyến mãi, `.tabs` cho mô tả / đánh giá |
| Blog / tạp chí | `.layout-sidebar`, `.prose` cho bài viết, `.list-ranked` cho bài đọc nhiều, `.tag` cho chủ đề |
| Tin tức | `.layout-3col`, logo chữ `.display`, `.topbar` ngày giờ. Xem `examples/news/` |
| Hồ sơ / portfolio | `.display` cho tên, `.tagline`, lưới `.card` dự án, `.spec` cho thông tin |
| Tài liệu / quản trị | `.layout-sidebar` với menu dọc `.list-ruled`, `.table`, `.alert`, `.tabs` |

## Nguyên tắc

1. Chỉ dùng token ngữ nghĩa; không viết mã màu rời. Cần màu mới thì thêm vào `tokens.css` kèm ghi chú vai trò.
2. Tiêu đề luôn Playfair Display, còn lại Noto Serif. Không thêm họ chữ thứ ba.
3. Không bo góc, không đổ bóng, không gradient trang trí (trừ ô giữ chỗ ảnh).
4. Mỗi màn hình chỉ một nút đỏ chính; hành động phụ dùng `.btn` viền mực.
5. Vàng đồng `--color-highlight` chỉ đặt trên nền tối.
6. Nhóm phần tử cùng cấp bằng flex / grid + `gap`, không dùng margin lẻ.
7. Chưa có ảnh thật thì dùng `.ph`, luân phiên 8 biến thể; không tạo gradient mới.
8. Biểu tượng vẽ bằng SVG nội tuyến, nét mảnh, màu `currentColor`; không emoji, không icon font.
9. Văn bản tiếng Việt, câu ngắn, giọng khách quan. Dữ kiện chưa có (tên, số điện thoại, giá, ngày…) để trong `[ ]`, không bịa.
10. Thiết kế từ điện thoại lên: kiểm tra ở 390px và 1080px.
